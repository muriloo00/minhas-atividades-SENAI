import './App.css'

function App() {
const nome = "Seu nome"
  return (
  <div>
   <h1>Olá, {nome}!</h1>
   <h2>curso: desenvolvimento de sistemas</h2>
   <p>eu quero aprender programação e ter uma boa carreira</p>
   <p>Meu hobby é jogar video games</p>
   <p>quero aprender programação</p>

   <img
  src="https://https://i.pinimg.com/736x/be/fe/e0/befee0cebe3eb0cabc8ed0d010eb1896.jpg"
  alt="Minha foto"
/>
<ul>
  <li>video games</li>
  <li>celular</li>
  <li>meu pc</li>
</ul>
  </div>
  
 );

}

export default App
