const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const startButton = document.getElementById("startButton");
const coinCountElement = document.getElementById("coinCount");
const livesElement = document.getElementById("lives");
const messageElement = document.getElementById("message");

let stamina = 100;
const doubleJumpCost = 20;
let cameraX = 0;

const world = {
  width: 1800,
  height: 540,
  gravity: 0.52,
  state: "ready",
  lastTime: 0,
  totalCoins: 13,
  phase: 1,
};

const keys = {
  left: false,
  right: false,
  jump: false,
  dash: false,
};

let player;
let platforms;
let coins;
let spikes;
let enemies;
let goal;
let particles;
let projectiles;
let checkpoints;
let currentCheckpoint = -1;

function resetGame() {
  stamina = 100;
  cameraX = 0;
  currentCheckpoint = -1;

  player = {
    x: 82,
    y: 380,
    width: 22,
    height: 32,
    vx: 0,
    vy: 0,
    onGround: false,
    wallSliding: false,
    coyoteTime: 0,
    jumpBuffer: 0,
    facing: 1,
    lives: 3,
    extraJumps: 1,
    dashCooldown: 0,
    dashTimer: 0,
    dashDir: 1,
    staminaCooldown: 0,
    auraTimer: 0,
  };

  platforms = [
    { x: 0, y: 470, w: 175, h: 70 },
    { x: 205, y: 430, w: 105, h: 20 },
    { x: 345, y: 380, w: 115, h: 20 },
    { x: 495, y: 325, w: 105, h: 20 },
    { x: 635, y: 385, w: 100, h: 20 },
    { x: 770, y: 315, w: 105, h: 20 },
    { x: 700, y: 220, w: 90, h: 20 },
    { x: 835, y: 165, w: 75, h: 20 },
    { x: 850, y: 470, w: 110, h: 70 },
    { x: 930, y: 470, w: 180, h: 70 },
    { x: 980, y: 420, w: 120, h: 20 },
    { x: 1080, y: 245, w: 18, h: 175 },
    { x: 1135, y: 350, w: 105, h: 20 },
    { x: 1180, y: 245, w: 130, h: 20 },
    { x: 1275, y: 280, w: 125, h: 20 },
    { x: 1360, y: 210, w: 90, h: 20 },
    { x: 1390, y: 470, w: 170, h: 70 },
    { x: 1450, y: 360, w: 110, h: 20 },
    { x: 1535, y: 205, w: 18, h: 265 },
    { x: 1600, y: 290, w: 105, h: 20 },
    { x: 1510, y: 145, w: 120, h: 20 },
    { x: 1710, y: 470, w: 90, h: 70 },
  ];

  spikes = [];

  checkpoints = [
    { x: 640, y: 335, w: 22, h: 50, spawnX: 630, spawnY: 353, active: false },
    { x: 1025, y: 370, w: 22, h: 50, spawnX: 1015, spawnY: 388, active: false },
    { x: 1445, y: 310, w: 22, h: 50, spawnX: 1435, spawnY: 328, active: false },
  ];

  coins = [
    { x: 90, y: 430, r: 12, collected: false },
    { x: 255, y: 390, r: 12, collected: false },
    { x: 400, y: 340, r: 12, collected: false },
    { x: 545, y: 285, r: 12, collected: false },
    { x: 685, y: 345, r: 12, collected: false },
    { x: 735, y: 180, r: 12, collected: false },
    { x: 870, y: 125, r: 12, collected: false },
    { x: 1040, y: 380, r: 12, collected: false },
    { x: 1185, y: 310, r: 12, collected: false },
    { x: 1335, y: 240, r: 12, collected: false },
    { x: 1505, y: 320, r: 12, collected: false },
    { x: 1650, y: 250, r: 12, collected: false },
    { x: 1750, y: 430, r: 12, collected: false },
  ];

  const enemyPool = [
    { x: 225, y: 400, w: 34, h: 30, minX: 205, maxX: 310, dir: 1, type: "walker" },
    { x: 370, y: 350, w: 34, h: 30, minX: 345, maxX: 460, dir: 1, type: "shooter", shotCooldown: 1.2 },
    { x: 520, y: 295, w: 34, h: 30, minX: 495, maxX: 600, dir: 1, type: "walker" },
    { x: 655, y: 355, w: 34, h: 30, minX: 635, maxX: 735, dir: 1, type: "shooter", shotCooldown: 1.8 },
    { x: 795, y: 285, w: 34, h: 30, minX: 770, maxX: 875, dir: 1, type: "walker" },
  ];
  enemies = world.phase === 5
    ? enemyPool.filter((enemy) => enemy.type === "shooter")
    : enemyPool.filter((enemy) => enemy.type === "walker");

  goal = { x: 1740, y: 400, w: 46, h: 70, active: false };
  particles = [];
  projectiles = [];
  updateHud();
}

function updateHud() {
  const collected = coins.filter((coin) => coin.collected).length;
  coinCountElement.textContent = collected;
  livesElement.textContent = "\u2665".repeat(Math.max(0, player.lives));
}

function startGame() {
  if (world.state === "won") {
    world.phase += 1;
  }
  resetGame();
  world.state = "playing";
  const enemyHint = world.phase === 5
    ? " Fase 5: apenas atiradores estarão no caminho."
    : " Evite os guardiões terrestres.";
  messageElement.textContent = `Fase ${world.phase}: colete 13 estrelas e atravesse o mapa!${enemyHint}`;
  world.lastTime = performance.now();
  requestAnimationFrame(loop);
}

function triggerDash() {
  if (player.dashCooldown > 0 || stamina < 50 || world.state !== "playing") return;

  const dashDirection = keys.left ? -1 : keys.right ? 1 : player.facing;
  player.dashDir = dashDirection;
  player.dashCooldown = 0.55;
  player.dashTimer = 0.22;
  player.auraTimer = 0.28;
  player.vx = dashDirection * 11.5;
  player.vy *= 0.35;
  stamina = Math.max(0, stamina - 50);
  player.staminaCooldown = 0.7;
  createParticles(player.x + player.width / 2, player.y + player.height / 2, "#5eead4");
  createParticles(player.x + player.width / 2, player.y + player.height / 2, "#ef4444");
  updateHud();
}

function loop(time) {
  if (world.state !== "playing") return;

  const delta = Math.min((time - world.lastTime) / 16.67, 2.1);
  world.lastTime = time;

  update(delta);
  draw();

  requestAnimationFrame(loop);
}

function update(delta) {
  player.auraTimer = Math.max(0, player.auraTimer - delta / 60);

  if (player.staminaCooldown > 0) {
    player.staminaCooldown -= 1 / 60;
  } else {
    stamina = Math.min(100, stamina + delta * 14);
  }

  if (player.dashCooldown > 0) player.dashCooldown -= 1 / 60;
  if (player.dashTimer > 0) {
    player.dashTimer -= 1 / 60;
    player.vx = player.dashDir * 11.5;
    player.vy *= 0.86;
    if (player.dashTimer <= 0) {
      player.vx *= 0.75;
    }
  }

  player.jumpBuffer = Math.max(0, player.jumpBuffer - 1 / 60);
  if (player.onGround) {
    player.coyoteTime = 0.12;
    player.extraJumps = 1;
  } else {
    player.coyoteTime = Math.max(0, player.coyoteTime - 1 / 60);
  }

  const moveInput = (keys.left ? -1 : 0) + (keys.right ? 1 : 0);
  const targetSpeed = moveInput * 4.8;
  const acceleration = player.onGround ? 0.8 : 0.55;

  if (moveInput !== 0) {
    player.vx += (targetSpeed - player.vx) * acceleration;
    player.facing = moveInput;
  } else {
    player.vx *= player.onGround ? 0.72 : 0.93;
    if (Math.abs(player.vx) < 0.03) player.vx = 0;
  }

  const wallGrip = getWallContact();
  player.wallSliding = !player.onGround && wallGrip !== 0 && player.vy > 0;
  if (player.wallSliding) {
    player.vy = Math.min(player.vy, 2.3);
  }

  if (keys.jump && !player.jumpHeld) {
    player.jumpBuffer = 0.12;
  }
  player.jumpHeld = keys.jump;

  const canJump = player.jumpBuffer > 0 && (player.onGround || player.coyoteTime > 0 || player.wallSliding);
  if (canJump) {
    if (player.wallSliding) {
      player.vy = -13.5;
      player.onGround = false;
      player.coyoteTime = 0;
      player.jumpBuffer = 0;
      player.vx = wallGrip * 6.2;
      player.extraJumps = 1;
    } else if (player.onGround || player.coyoteTime > 0) {
      player.vy = -12.8;
      player.onGround = false;
      player.coyoteTime = 0;
      player.jumpBuffer = 0;
      player.extraJumps = 1;
    }
  } else if (
    player.jumpBuffer > 0 &&
    !player.onGround &&
    !player.wallSliding &&
    player.extraJumps > 0 &&
    stamina >= doubleJumpCost
  ) {
    player.vy = -12.2;
    player.jumpBuffer = 0;
    player.extraJumps -= 1;
    stamina -= doubleJumpCost;
    player.staminaCooldown = Math.max(player.staminaCooldown, 0.25);
    player.auraTimer = 0.24;
    createParticles(player.x + player.width / 2, player.y + player.height / 2, "#ef4444");
    updateHud();
  }

  player.vy += world.gravity * delta;
  player.x += player.vx * delta;
  player.y += player.vy * delta;

  resolveCollisions();
  cameraX = Math.max(0, Math.min(world.width - canvas.width, player.x - canvas.width * 0.35));

  for (const coin of coins) {
    if (!coin.collected) {
      const dx = player.x + player.width / 2 - coin.x;
      const dy = player.y + player.height / 2 - coin.y;
      if (Math.hypot(dx, dy) < 24) {
        coin.collected = true;
        createParticles(coin.x, coin.y, "#facc15");
        updateHud();
      }
    }
  }

  const collected = coins.filter((coin) => coin.collected).length;
  goal.active = collected >= world.totalCoins;
  updateHud();

  for (let index = 0; index < checkpoints.length; index += 1) {
    const checkpoint = checkpoints[index];
    const reached =
      player.x < checkpoint.x + checkpoint.w &&
      player.x + player.width > checkpoint.x &&
      player.y < checkpoint.y + checkpoint.h &&
      player.y + player.height > checkpoint.y;

    if (reached && index > currentCheckpoint) {
      currentCheckpoint = index;
      checkpoints.forEach((item, checkpointIndex) => {
        item.active = checkpointIndex <= currentCheckpoint;
      });
      player.lives = 3;
      createParticles(checkpoint.x + checkpoint.w / 2, checkpoint.y + 12, "#4ade80");
      updateHud();
      messageElement.textContent = `Checkpoint ${index + 1} ativado! Vidas restauradas.`;
    }
  }

  for (const enemy of enemies) {
    enemy.x += enemy.dir * 1.5 * delta;
    if (enemy.x < enemy.minX || enemy.x + enemy.w > enemy.maxX) {
      enemy.dir *= -1;
      enemy.x = Math.max(enemy.minX, Math.min(enemy.maxX - enemy.w, enemy.x));
    }

    if (enemy.type === "shooter") {
      enemy.shotCooldown -= delta / 60;
      if (enemy.shotCooldown <= 0) {
        createProjectile(enemy);
        enemy.shotCooldown = 1.8;
      }
    }

    const hit =
      player.x < enemy.x + enemy.w &&
      player.x + player.width > enemy.x &&
      player.y < enemy.y + enemy.h &&
      player.y + player.height > enemy.y;

    if (hit && player.dashTimer <= 0) {
      damagePlayer("Tomou dano! Continue firme.");
      return;
    }
  }

  for (const projectile of projectiles) {
    projectile.x += projectile.vx * delta;
    projectile.y += projectile.vy * delta;
    projectile.life -= delta / 60;

    const hitProjectile =
      player.x < projectile.x + projectile.radius &&
      player.x + player.width > projectile.x - projectile.radius &&
      player.y < projectile.y + projectile.radius &&
      player.y + player.height > projectile.y - projectile.radius;

    if (hitProjectile && player.dashTimer <= 0) {
      damagePlayer("Um projétil acertou você! Mantenha-se em movimento.");
      return;
    }
  }
  projectiles = projectiles.filter(
    (projectile) => projectile.life > 0 && projectile.x > -40 && projectile.x < world.width + 40,
  );

  for (const spike of spikes) {
    const hitSpike =
      player.x < spike.x + spike.w &&
      player.x + player.width > spike.x &&
      player.y < spike.y + spike.h &&
      player.y + player.height > spike.y;

    if (hitSpike) {
      damagePlayer("Espinhos! Tente um salto mais alto.");
      return;
    }
  }

  if (
    player.x + player.width > goal.x &&
    player.x < goal.x + goal.w &&
    player.y + player.height > goal.y &&
    player.y < goal.y + goal.h &&
    goal.active
  ) {
    world.state = "won";
    messageElement.textContent = `Fase ${world.phase} concluída! Clique em iniciar para avançar.`;
    return;
  }

  if (player.y > world.height + 120) {
    damagePlayer("Caiu! Mas ainda dá para voltar.");
  }
}

function damagePlayer(message) {
  player.lives -= 1;
  updateHud();

  if (player.lives <= 0) {
    world.state = "gameover";
    messageElement.textContent = "Você perdeu! Clique em iniciar para tentar de novo.";
    return;
  }

  const respawn = currentCheckpoint >= 0 ? checkpoints[currentCheckpoint] : null;
  player.x = respawn ? respawn.spawnX : 82;
  player.y = respawn ? respawn.spawnY : 380;
  player.vx = 0;
  player.vy = 0;
  player.onGround = false;
  messageElement.textContent = message;
}

function getWallContact() {
  for (const platform of platforms) {
    const onLeft =
      player.x + player.width > platform.x &&
      player.x < platform.x + 8 &&
      player.y + player.height > platform.y + 4 &&
      player.y < platform.y + platform.h;

    const onRight =
      player.x < platform.x + platform.w &&
      player.x + player.width > platform.x + platform.w - 8 &&
      player.y + player.height > platform.y + 4 &&
      player.y < platform.y + platform.h;

    if (onLeft) return -1;
    if (onRight) return 1;
  }
  return 0;
}

function resolveCollisions() {
  player.onGround = false;

  for (const platform of platforms) {
    const playerLeft = player.x;
    const playerRight = player.x + player.width;
    const playerTop = player.y;
    const playerBottom = player.y + player.height;

    const platLeft = platform.x;
    const platRight = platform.x + platform.w;
    const platTop = platform.y;
    const platBottom = platform.y + platform.h;

    const intersects =
      playerRight > platLeft &&
      playerLeft < platRight &&
      playerBottom > platTop &&
      playerTop < platBottom;

    if (!intersects) continue;

    const previousBottom = player.y - player.vy + player.height;
    const previousTop = player.y - player.vy;

    if (previousBottom <= platTop + 14 && player.vy >= 0) {
      player.y = platTop - player.height;
      player.vy = 0;
      player.onGround = true;
    } else if (previousTop >= platBottom - 14 && player.vy < 0) {
      player.y = platBottom;
      player.vy = 0;
    } else if (player.x + player.width <= platLeft + 12 && player.vx > 0) {
      player.x = platLeft - player.width;
      player.vx = 0;
    } else if (player.x >= platRight - 12 && player.vx < 0) {
      player.x = platRight;
      player.vx = 0;
    }
  }

  if (player.x < 0) {
    player.x = 0;
    player.vx = 0;
  }

  if (player.x + player.width > world.width) {
    player.x = world.width - player.width;
    player.vx = 0;
  }
}

function createParticles(x, y, color) {
  for (let i = 0; i < 16; i += 1) {
    particles.push({
      x,
      y,
      vx: (Math.random() - 0.5) * 3,
      vy: -Math.random() * 2.5,
      life: 1,
      color,
      size: 4 + Math.random() * 4,
    });
  }
}

function createProjectile(enemy) {
  const startX = enemy.x + enemy.w / 2;
  const startY = enemy.y + enemy.h / 2;
  const targetX = player.x + player.width / 2;
  const targetY = player.y + player.height / 2;
  const angle = Math.atan2(targetY - startY, targetX - startX);

  projectiles.push({
    x: startX,
    y: startY,
    vx: Math.cos(angle) * 4.2,
    vy: Math.sin(angle) * 4.2,
    radius: 6,
    life: 3,
  });
}

function updateParticles() {
  for (const particle of particles) {
    particle.x += particle.vx;
    particle.y += particle.vy;
    particle.vy += 0.08;
    particle.life -= 0.02;
  }
  particles = particles.filter((particle) => particle.life > 0);
}

function drawBackground() {
  const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
  gradient.addColorStop(0, "#081521");
  gradient.addColorStop(1, "#173a5d");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  for (let i = 0; i < 35; i += 1) {
    const x = (i * 97) % canvas.width;
    const y = (i * 53) % 250;
    ctx.fillStyle = "rgba(255,255,255,0.35)";
    ctx.fillRect(x, y, 2, 2);
  }
}

function drawPlatforms() {
  for (const [index, platform] of platforms.entries()) {
    const accent = index % 2 === 0 ? "#2dd4bf" : "#38bdf8";
    const isWall = platform.h > 60 && platform.w < 40;

    ctx.fillStyle = "rgba(6, 18, 35, 0.8)";
    ctx.fillRect(
      platform.x + (isWall ? platform.w : 4),
      platform.y + (isWall ? 4 : platform.h),
      isWall ? 7 : platform.w - 2,
      isWall ? platform.h - 2 : 7,
    );

    ctx.fillStyle = "#123047";
    ctx.fillRect(platform.x, platform.y, platform.w, platform.h);

    ctx.fillStyle = accent;
    if (isWall) {
      ctx.fillRect(platform.x, platform.y, 4, platform.h);
      ctx.fillRect(platform.x + platform.w - 4, platform.y, 4, platform.h);
    } else {
      ctx.fillRect(platform.x, platform.y, platform.w, 4);
    }
    ctx.fillStyle = "rgba(255,255,255,0.22)";
    if (isWall) {
      ctx.fillRect(platform.x + 7, platform.y + 10, 2, Math.max(10, platform.h - 28));
    } else {
      ctx.fillRect(platform.x + 8, platform.y + 7, Math.max(10, platform.w - 28), 2);
    }

    ctx.fillStyle = accent;
    if (isWall) {
      for (let y = platform.y + 16; y < platform.y + platform.h - 8; y += 28) {
        ctx.fillRect(platform.x + 7, y, 4, 3);
      }
    } else {
      for (let x = platform.x + 12; x < platform.x + platform.w - 8; x += 28) {
        ctx.fillRect(x, platform.y + platform.h - 6, 3, 3);
      }
    }
  }
}

function drawSpikes() {
  for (const spike of spikes) {
    const count = Math.floor(spike.w / 8);
    ctx.fillStyle = "#240b16";
    ctx.fillRect(spike.x, spike.y + spike.h - 5, spike.w, 5);

    ctx.shadowColor = "#ef4444";
    ctx.shadowBlur = 9;
    for (let i = 0; i < count; i += 1) {
      const x = spike.x + i * 8;
      const tipOffset = i % 2 === 0 ? 0 : 3;
      ctx.fillStyle = i % 2 === 0 ? "#ef4444" : "#fb7185";
      ctx.beginPath();
      ctx.moveTo(x, spike.y + spike.h - 4);
      ctx.lineTo(x + 4, spike.y + tipOffset);
      ctx.lineTo(x + 8, spike.y + spike.h - 4);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = "#fecaca";
      ctx.fillRect(x + 3, spike.y + 5 + tipOffset, 2, 5);
    }
    ctx.shadowBlur = 0;
  }
}

function drawCoins() {
  for (const coin of coins) {
    if (coin.collected) continue;
    ctx.fillStyle = "#facc15";
    ctx.beginPath();
    ctx.arc(coin.x, coin.y, coin.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#fef3c7";
    ctx.beginPath();
    ctx.arc(coin.x - 3, coin.y - 3, coin.r / 2.5, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawGoal() {
  ctx.fillStyle = goal.active ? "#4ade80" : "#64748b";
  ctx.fillRect(goal.x, goal.y, goal.w, goal.h);
  ctx.strokeStyle = "#e2e8f0";
  ctx.strokeRect(goal.x + 5, goal.y + 5, goal.w - 10, goal.h - 10);
}

function drawEnemies() {
  for (const enemy of enemies) {
    const ex = enemy.x;
    const ey = enemy.y;
    const ew = enemy.w;
    const eh = enemy.h;

    const isShooter = enemy.type === "shooter";
    ctx.fillStyle = isShooter ? "#8b5cf6" : "#f97316";
    ctx.fillRect(ex + 4, ey + 2, ew - 8, eh - 4);

    ctx.fillStyle = isShooter ? "#c4b5fd" : "#fbbf24";
    ctx.fillRect(ex + 8, ey + 2, 6, 8);
    ctx.fillRect(ex + ew - 14, ey + 2, 6, 8);

    ctx.fillStyle = "#1f2937";
    ctx.fillRect(ex + 10, ey + 8, 5, 7);
    ctx.fillRect(ex + ew - 15, ey + 8, 5, 7);

    ctx.strokeStyle = isShooter ? "#e9d5ff" : "#fca5a5";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(ex + 10, ey + 17);
    ctx.lineTo(ex + ew / 2, ey + 11);
    ctx.lineTo(ex + ew - 10, ey + 17);
    ctx.stroke();

    ctx.fillStyle = "#111827";
    ctx.fillRect(ex + 7, ey + 18, ew - 14, 6);

    ctx.fillStyle = isShooter ? "#22d3ee" : "#fb7185";
    ctx.fillRect(ex + 5, ey + 22, 5, 10);
    ctx.fillRect(ex + ew - 10, ey + 22, 5, 10);

    ctx.fillStyle = "#111827";
    ctx.fillRect(ex + 4, ey + 2, 4, 6);
    ctx.fillRect(ex + ew - 8, ey + 2, 4, 6);

    if (isShooter) {
      ctx.fillStyle = "#111827";
      ctx.fillRect(ex + ew / 2 - 4, ey + 25, 8, 8);
      ctx.fillStyle = "#67e8f9";
      ctx.fillRect(ex + ew / 2 - 2, ey + 26, 4, 5);
    }
  }
}

function drawProjectiles() {
  for (const projectile of projectiles) {
    ctx.fillStyle = "#ef4444";
    ctx.shadowColor = "#fb7185";
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(projectile.x, projectile.y, projectile.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#fee2e2";
    ctx.beginPath();
    ctx.arc(projectile.x - 2, projectile.y - 2, 2, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawPlayer() {
  const px = player.x;
  const py = player.y;
  const pw = player.width;
  const ph = player.height;

  ctx.save();
  ctx.translate(px + pw / 2, py + ph / 2);
  ctx.scale(player.facing, 1);
  ctx.translate(-(px + pw / 2), -(py + ph / 2));

  const aura = player.auraTimer > 0 ? "#ef4444" : "#a78bfa";
  ctx.fillStyle = aura;
  ctx.globalAlpha = player.auraTimer > 0 ? 0.42 : 0.18;
  ctx.shadowColor = aura;
  ctx.shadowBlur = player.auraTimer > 0 ? 18 : 0;
  ctx.fillRect(px - 5, py - 5, pw + 10, ph + 10);
  ctx.shadowBlur = 0;
  ctx.globalAlpha = 1;

  ctx.fillStyle = "#7f1d1d";
  ctx.fillRect(px + 1, py + 1, pw - 2, ph - 2);
  ctx.fillStyle = "#ef4444";
  ctx.fillRect(px + 4, py + 4, pw - 8, ph - 10);
  ctx.fillStyle = "#f87171";
  ctx.fillRect(px + 5, py + 5, pw - 10, 5);
  ctx.fillStyle = "#991b1b";
  ctx.fillRect(px + 4, py + ph - 7, pw - 8, 4);

  if (player.wallSliding) {
    ctx.strokeStyle = "#5eead4";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(px + 5, py + 3);
    ctx.lineTo(px + 5, py + ph - 3);
    ctx.stroke();
  }

  const staminaWidth = 42;
  const staminaHeight = 5;
  const staminaX = px + pw / 2 - staminaWidth / 2;
  const staminaY = py - 11;
  const staminaColor = "#ef4444";

  ctx.fillStyle = "rgba(4, 10, 24, 0.86)";
  ctx.fillRect(staminaX - 2, staminaY - 2, staminaWidth + 4, staminaHeight + 4);
  ctx.fillStyle = staminaColor;
  ctx.shadowColor = staminaColor;
  ctx.shadowBlur = 8;
  ctx.fillRect(staminaX, staminaY, staminaWidth * (stamina / 100), staminaHeight);
  ctx.shadowBlur = 0;

  ctx.restore();
}

function drawParticles() {
  for (const particle of particles) {
    ctx.fillStyle = particle.color;
    ctx.globalAlpha = particle.life;
    ctx.fillRect(particle.x, particle.y, particle.size, particle.size);
    ctx.globalAlpha = 1;
  }
}

function drawCheckpoints() {
  const pulse = 0.78 + Math.sin(performance.now() / 180) * 0.22;
  checkpoints.forEach((checkpoint, index) => {
    const color = checkpoint.active ? "#4ade80" : "#facc15";
    ctx.fillStyle = "#172033";
    ctx.fillRect(checkpoint.x + 9, checkpoint.y, 6, checkpoint.h);
    ctx.globalAlpha = pulse * 0.28;
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 22;
    ctx.fillRect(checkpoint.x - 4, checkpoint.y - 5, checkpoint.w + 24, checkpoint.h + 10);
    ctx.globalAlpha = 1;
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = checkpoint.active ? 18 : 12;
    ctx.beginPath();
    ctx.moveTo(checkpoint.x + 14, checkpoint.y + 1);
    ctx.lineTo(checkpoint.x + 38, checkpoint.y + 10);
    ctx.lineTo(checkpoint.x + 14, checkpoint.y + 19);
    ctx.closePath();
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#cbd5e1";
    ctx.fillRect(checkpoint.x + 3, checkpoint.y + checkpoint.h - 4, 18, 4);
    ctx.fillStyle = "#f8fafc";
    ctx.font = "700 10px Arial";
    ctx.fillText(`CP ${index + 1}`, checkpoint.x - 3, checkpoint.y - 9);
  });
}

function drawMiniMap() {
  const mapWidth = 190;
  const mapHeight = 68;
  const mapX = canvas.width - mapWidth - 16;
  const mapY = 16;
  const scaleX = mapWidth / world.width;
  const scaleY = mapHeight / world.height;

  ctx.save();
  ctx.fillStyle = "rgba(4, 10, 24, 0.84)";
  ctx.fillRect(mapX, mapY, mapWidth, mapHeight);
  ctx.strokeStyle = "rgba(248, 113, 113, 0.7)";
  ctx.lineWidth = 1;
  ctx.strokeRect(mapX, mapY, mapWidth, mapHeight);

  ctx.fillStyle = "rgba(255, 255, 255, 0.22)";
  for (const platform of platforms) {
    ctx.fillRect(
      mapX + platform.x * scaleX,
      mapY + platform.y * scaleY,
      Math.max(3, platform.w * scaleX),
      Math.max(2, platform.h * scaleY),
    );
  }

  ctx.strokeStyle = "rgba(239, 68, 68, 0.55)";
  ctx.strokeRect(mapX + cameraX * scaleX, mapY, canvas.width * scaleX, mapHeight);

  for (const [index, checkpoint] of checkpoints.entries()) {
    ctx.fillStyle = checkpoint.active ? "#4ade80" : "#facc15";
    ctx.shadowColor = ctx.fillStyle;
    ctx.shadowBlur = 8;
    ctx.fillRect(
      mapX + checkpoint.x * scaleX - 2,
      mapY + checkpoint.y * scaleY - 3,
      7,
      9,
    );
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#f8fafc";
    ctx.font = "700 7px Arial";
    ctx.fillText(`C${index + 1}`, mapX + checkpoint.x * scaleX - 2, mapY + checkpoint.y * scaleY - 5);
  }

  ctx.fillStyle = "#ef4444";
  ctx.fillRect(mapX + player.x * scaleX - 2, mapY + player.y * scaleY - 2, 5, 5);
  ctx.fillStyle = "#4ade80";
  ctx.fillRect(mapX + goal.x * scaleX - 2, mapY + goal.y * scaleY - 2, 5, 5);
  ctx.restore();
}

function draw() {
  drawBackground();
  ctx.save();
  ctx.translate(-cameraX, 0);
  drawPlatforms();
  drawSpikes();
  drawCoins();
  drawGoal();
  drawCheckpoints();
  drawEnemies();
  drawProjectiles();
  drawPlayer();
  drawParticles();
  ctx.restore();
  drawMiniMap();
  updateParticles();
}

window.addEventListener("keydown", (event) => {
  const key = event.key.toLowerCase();

  if (event.repeat && (event.shiftKey || key === "x")) return;

  if (key === "a" || key === "arrowleft") keys.left = true;
  if (key === "d" || key === "arrowright") keys.right = true;
  if (key === "w" || key === "arrowup" || key === " ") {
    keys.jump = true;
    event.preventDefault();
  }
  if (event.shiftKey || key === "x") {
    keys.dash = true;
    triggerDash();
  }

  if (key === "enter" && world.state !== "playing") {
    startGame();
  }
});

window.addEventListener("keyup", (event) => {
  const key = event.key.toLowerCase();

  if (key === "a" || key === "arrowleft") keys.left = false;
  if (key === "d" || key === "arrowright") keys.right = false;
  if (key === "w" || key === "arrowup" || key === " ") keys.jump = false;
  if (event.shiftKey || key === "x") keys.dash = false;
});

startButton.addEventListener("click", startGame);

resetGame();
updateHud();
draw();
